// APARTADO 3 · Componente ResumenNotas
// Ahora muestra datos fijos. Hay que convertirlo en un componente configurable mediante props.

export function ResumenNotas() {
  return (
    <section className="resumen">
      <h2>Resumen</h2>
      <p>
        Nota media: <strong>0.00</strong>
      </p>
      <p>Módulos aprobados: 0 de 0</p>
    </section>
  );
}
