// APARTADO 5 · Componente FormularioNota
// Ahora es un formulario estático que no hace nada. Hay que hacerlo funcional.

export function FormularioNota() {
  return (
    <form className="formulario">
      <h2>Añadir nota</h2>
      <div className="campo">
        <label htmlFor="modulo">Módulo</label>
        <input id="modulo" type="text" />
      </div>
      <div className="campo">
        <label htmlFor="calificacion">Calificación (0 a 10)</label>
        <input id="calificacion" type="number" min="0" max="10" step="0.1" />
      </div>
      <div className="campo">
        <label htmlFor="observaciones">Observaciones (opcional)</label>
        <input id="observaciones" type="text" />
      </div>
      <button type="submit">Añadir nota</button>
    </form>
  );
}
