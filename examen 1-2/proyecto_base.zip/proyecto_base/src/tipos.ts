// APARTADO 1 · Tipos
// Escribe aquí los tipos `Nota` y `Resultado` (consulta el enunciado).

export {};
